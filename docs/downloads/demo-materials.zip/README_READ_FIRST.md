# Presentation package

Viktor Khudiaiev — September 2026

## Start here

Extract the entire ZIP and open START_HERE.html or docs/index.html.
The explanation HTML needs no Internet, Node, Java or Docker.
Keep the companion documents in their extracted folders.

1. Overview: the problem, control, execution and limits in four short blocks.
2. Architecture: twelve numbered arrows across three modules, two PostgreSQL databases and embedded ActiveMQ.
3. Sequence: the full normal-transfer path with separate participant lifelines.
4. Evidence, Terms and Materials: retained results, definitions and the talk pack.

The explanation diagrams do NOT connect to an API or calculate a real HMAC.
The separate Live Lab page DOES call the actual stack when opened through the
full project's loopback-only helper at http://127.0.0.1:8090/docs/live/index.html.
It supports protected funding, a valid transfer, direct-primary forgery, safe
retries and fresh demonstration identities; all funds are simulated. The page
alone cannot run experiments. The Java/PostgreSQL stack and helper backend are
not in this archive. The handbook commands require the full source checkout.
Replace C:\path\to\record-integrity with your path.
References to omitted code appear as labels with paths in the full source checkout.

## Files

- docs/index.html — offline interactive walkthrough.
- docs/live/index.html — real transaction lab entry point and startup instructions.
- docs/live/client.js — lab page client, without backend credentials.
- docs/article/index.html — updated article in the browser.
- docs/article/article.pdf — updated technical article.
- docs/presentation/demo.pptx — 14 editable
  slides with detailed speaker notes in PowerPoint notes view.
- docs/presentation/notes.md — the same talk notes separately.
- docs/presentation/guide.html — Rehearsal and Q&A handbook.
- docs/evidence/*.json — retained verification, recovery and Live Lab reports.
- docs/reference/protocol.md — exact encoding and key-custody protocol.
- CanonicalEncoderTest.java under tokenization-module/src/test — public golden
  vectors only. Its repeated 0b test key is intentionally public, never a runtime key.
- MANIFEST.json — SHA-256 digests of every packaged file except the manifest itself.

## Boundaries

The package contains no service binaries, databases, real secret keys, credentials
or .local directory. Public test constants are not deployment credentials.
The workload was offered at 20 TPS for 120 seconds: 2,400 unique completions,
zero failures; 20.3091 steady completed TPS and 19.9371 whole-run TPS. This is
September 6 two-database / ActiveMQ evidence from one local software-key Windows host, not a production SLA.

The production architecture is a target, not deployed infrastructure. Links to
external RFCs and vendor documentation require Internet when opened. Offline
content and the teaching model themselves do not require those sites.

No venue-specific conference template has been applied. No public repository URL
has been invented. The original source article has not been overwritten.
