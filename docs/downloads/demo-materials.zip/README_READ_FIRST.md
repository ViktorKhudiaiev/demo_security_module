# Presentation package

Viktor Khudiaiev — September 2026

## Start here

Extract the entire ZIP and open START_HERE.html or docs/index.html.
The explanation HTML needs no Internet, Node, Java or Docker.
Keep the companion documents in their extracted folders.

1. Overview: the problem, control, execution and limits in four short blocks.
2. Architecture: twelve numbered arrows across three modules, two PostgreSQL databases and embedded ActiveMQ.
3. Sequence: the full normal-transfer path with separate participant lifelines.
4. Evidence, Terms and Materials: retained results, definitions and the talk pack.

The explanation diagrams do NOT connect to an API or calculate a real HMAC.
The separate Live Lab page DOES call the actual stack when opened through the
full project's loopback-only helper at http://127.0.0.1:8090/docs/live/index.html.
It supports protected funding, a valid transfer, direct-primary forgery, safe
retries and fresh demonstration identities; all funds are simulated. The page
alone cannot run experiments. The Java/PostgreSQL stack and helper backend are
not in this archive. The handbook commands require the full source checkout.
Replace C:\path\to\record-integrity with your path.
References to omitted code appear as labels with paths in the full source checkout.

## Files

- docs/index.html — offline interactive walkthrough.
- docs/live/index.html — real transaction lab entry point and startup instructions.
- docs/live/client.js — lab page client, without backend credentials.
- docs/article/index.html — updated article in the browser.
- docs/article/article.pdf — updated technical article.
- docs/presentation/demo.pptx — 14 editable
  slides with detailed speaker notes in PowerPoint notes view.
- docs/presentation/notes.md — the same talk notes separately.
- docs/presentation/guide.html — Rehearsal and Q&A handbook.
- docs/reference/notifications.md — incident email setup, retries and capture limits.
- docs/evidence/*.json — dated verification, recovery, Live Lab and notification reports,
  including the latest strict-throughput failure rather than only historical passes.
- docs/reference/protocol.md — exact encoding and key-custody protocol.
- CanonicalEncoderTest.java under tokenization-module/src/test — public golden
  vectors only. Its repeated 0b test key is intentionally public, never a runtime key.
- MANIFEST.json — SHA-256 digests of every packaged file except the manifest itself.

## Boundaries

The package contains no service binaries, databases, real secret keys, credentials
or .local directory. Public test constants are not deployment credentials.
The latest full load run, September 7, offered 20 TPS for 120 seconds and completed
all 2,400 unique operations with correct protected accounting and audit, with zero
transaction failures. Steady throughput was 19.9636 TPS, below the strict 20 TPS
threshold with zero tolerance: load and combined acceptance FAILED. Whole-run
throughput was 19.9403 TPS; p95 was 668 ms. Historical September 6 successes remain
separate dated evidence. These are local software-key Windows measurements, not a
production SLA or a new benchmark of the email-notification revision.

The September 8 notification revision passed 137 Java tests, 44 Node tests and
18 PostgreSQL role checks, plus four live notification scenarios. Two incident
messages were captured by local Mailpit; no external Gmail delivery was tested.
SMTP acceptance is not inbox delivery, and retry after an ambiguous failure can
duplicate an email. Notification delivery is a side channel, not an execution gate.

The production architecture is a target, not deployed infrastructure. Links to
external RFCs and vendor documentation require Internet when opened. Offline
content and the teaching model themselves do not require those sites.

No venue-specific conference template has been applied. The source repository is
https://github.com/ViktorKhudiaiev/demo_security_module. This package updates the
repository article, not the separately supplied original source PDF.
